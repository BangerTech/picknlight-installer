// ==UserScript==
// @name        PartDB Info Finder incl. Category with Popup
// @namespace   Violentmonkey Scripts
// @match       https://parts.server24-7.net/*
// @grant       none
// @version     3.2
// @description Partfinder mit modernisiertem Popup für Name, Kategorie und aktuelles Fach
// ==/UserScript==

(function () {
    'use strict';

    window.findPartInfo = function () {
        let partName = '';
        let partId = '';
        let category = '';

        // Finden des Namens
        const nameElement = document.querySelector("h3.w-fit");
        if (nameElement) {
            partName = nameElement.childNodes[0]?.textContent.trim();
        }

        // Finden der ID
        const floatEndElements = document.querySelectorAll(".float-end");
        if (floatEndElements.length > 0) {
            const content = floatEndElements[0]?.textContent.split(":");
            partId = content[1]?.trim();
        }

        // Finden der Kategorie (Textinhalt des <a>-Tags)
        const categoryElement = document.querySelector("a[href^='/de/category/']");
        if (categoryElement) {
            category = categoryElement.textContent.trim();
        } else {
            console.error("Kategorie konnte nicht gefunden werden.");
        }

        console.log('Gefundener Name:', partName);
        console.log('Gefundene ID:', partId);
        console.log('Gefundene Kategorie:', category);

        // Überprüfung, ob Name und ID vorhanden sind
        if (partName && partId) {
            const encodedName = encodeURIComponent(partName);
            const encodedCategory = encodeURIComponent(category);
            const url1 = `https://nodered.server24-7.net/partinfo?name=${encodedName}&id=${encodeURIComponent(partId)}&category=${encodedCategory}`;
            const url2 = `https://nodered.server24-7.net/inventoryname?getNAME=${encodedName}`;

            console.log('Konstruierte URL 1:', url1);
            console.log('Konstruierte URL 2:', url2);

            // API-Aufruf an URL 1 für Popup-Daten mit Verzögerung
            setTimeout(() => {
                fetch(url1, { mode: 'cors' })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log('Daten erfolgreich empfangen von URL 1:', data);
                        showPopup(data, category); // Zeigt das Popup an und übergibt die Kategorie
                    })
                    .catch(error => {
                        console.error('Fehler beim Senden der Daten an URL 1:', error);
                    });
            }, 500); // Verzögerung von 500 ms

            // API-Aufruf an URL 2 für Namensanzeige im Dashboard
            fetch(url2, { mode: 'cors' })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text();
                })
                .then(data => {
                    console.log('Daten erfolgreich gesendet an URL 2:', data);
                })
                .catch(error => {
                    console.error('Fehler beim Senden der Daten an URL 2:', error);
                });
        } else {
            console.log('Keine gültigen Daten gefunden. Popup wird nicht angezeigt.');
        }
    };

    // Funktion zum Anzeigen des Popups
    function showPopup(data, category) {
        const { speechText } = data; // Nutzt speechText wie in Version 2.6

        // Debugging: Überprüfen der empfangenen Daten
        console.log('Empfangene Daten für Popup:', data);

        // Falls keine Daten vorhanden sind
        if (!speechText) {
            console.error('Keine gültigen Daten für Popup.');
            return;
        }

        // Überprüfen, ob ein Popup bereits existiert
        let popupOverlay = document.getElementById('popup-overlay');
        if (!popupOverlay) {
            popupOverlay = document.createElement('div');
            popupOverlay.id = 'popup-overlay';
            popupOverlay.style.position = 'fixed';
            popupOverlay.style.top = '0';
            popupOverlay.style.left = '0';
            popupOverlay.style.width = '100%';
            popupOverlay.style.height = '100%';
            popupOverlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
            popupOverlay.style.zIndex = '9998';
            document.body.appendChild(popupOverlay);

            // Schließen bei Klick außerhalb des Popups
            popupOverlay.addEventListener('click', () => {
                popupOverlay.remove();
                const existingPopup = document.getElementById('partdb-popup');
                if (existingPopup) existingPopup.remove();
            });
        }

        let popup = document.getElementById('partdb-popup');
        if (!popup) {
            popup = document.createElement('div');
            popup.id = 'partdb-popup';
            popup.style.position = 'fixed';
            popup.style.top = '50%';
            popup.style.left = '50%';
            popup.style.transform = 'translate(-50%, -50%)';
            popup.style.backgroundColor = '#ffffff';
            popup.style.borderRadius = '16px';
            popup.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.3)';
            popup.style.padding = '20px';
            popup.style.zIndex = '9999';
            popup.style.fontFamily = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
            popup.style.color = '#333';
            popup.style.textAlign = 'center'; // Zentrierung des Inhalts
            popup.style.width = '90%'; // Anpassung für kleinere Bildschirme
            popup.style.maxWidth = '400px'; // Maximale Breite
            document.body.appendChild(popup);
        }

        // Extrahiere die Daten aus speechText
        const lines = speechText.split(', ');
        let name = '';
        let id = '';
        let location = '';

        // Extrahiere die Werte aus den Zeilen
        lines.forEach(line => {
            if (line.startsWith('Name: ')) name = line.replace('Name: ', '');
            if (line.startsWith('Bauteil-ID: ')) id = line.replace('Bauteil-ID: ', '');
            if (line.startsWith('Aktuelles Fach: ')) location = line.replace('Aktuelles Fach: ', '');
        });

        // Setze den Inhalt des Popups mit der gewünschten Reihenfolge
        popup.innerHTML = `
            <div style="margin-bottom: 16px;">
                <strong style="font-size: 30px; color: #444;">Bauteil-Informationen</strong>
            </div>
            <div style="line-height: 1.8; font-size: 16px; text-align: left;">
                <div>Name: <strong><em>${name}</em></strong></div>
                <div>Bauteil-ID: <strong><em>${id}</em></strong></div>
                <div>Kategorie: <strong><em>${category || 'Unbekannt'}</em></strong></div>
                <div>Aktuelles Fach: <strong><em>${location}</em></strong></div>
            </div>
        `;
    }

    // Ausführen der Funktion beim Laden der Seite
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', findPartInfo);
    } else {
        findPartInfo();
    }

    // MutationObserver für relevante DOM-Änderungen
    const observer = new MutationObserver((mutations) => {
        for (let mutation of mutations) {
            if (mutation.type === 'childList' && mutation.target.matches('h3.w-fit')) {
                findPartInfo();
                break;
            }
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

})();